// bridge.js
// Jalan di halaman HTML lokal kamu (file:// atau http://localhost/127.0.0.1).
// Terima permintaan dari halaman lewat window.postMessage({source:'sbx_req', ...}),
// teruskan ke background.js, lalu balas ke halaman lewat postMessage juga.
//
// Ini membuat halaman HTML kamu bisa minta ekstensi untuk fetch data Stockbit
// tanpa kena CORS, tanpa proxy worker eksternal, dan tanpa token manual.

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const d = event.data;
  if (!d || d.source !== "sbx_req") return;

  chrome.runtime.sendMessage(
    { type: "SBX_REQUEST", action: d.action, url: d.url },
    (res) => {
      window.postMessage(
        Object.assign({ source: "sbx_res", id: d.id }, res || { ok: false, error: "no response" }),
        "*"
      );
    }
  );
});

// Dorong baris hasil DOM-scrape (dari tab stockbit.com) ke halaman ini,
// setiap kali tersimpan baru di chrome.storage - ini genuinely push, bukan
// polling: listener ini hanya jalan saat ADA perubahan, tidak menjadwalkan
// pengecekan berkala sendiri.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.rtRows) return;
  const rows = changes.rtRows.newValue?.rows;
  if (!Array.isArray(rows) || !rows.length) return;
  window.postMessage({ source: "sbx_push", kind: "rt_rows", rows }, "*");
});

// Kirim juga snapshot yang sudah ada (kalau ada) begitu halaman ini dibuka,
// supaya tidak perlu menunggu perubahan baru di tab Stockbit dulu.
chrome.storage.local.get("rtRows", ({ rtRows }) => {
  if (rtRows && Array.isArray(rtRows.rows) && rtRows.rows.length) {
    window.postMessage({ source: "sbx_push", kind: "rt_rows", rows: rtRows.rows }, "*");
  }
});

console.log("[stockbit-bridge] bridge.js aktif di halaman ini");
