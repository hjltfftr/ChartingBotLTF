// dom-scraper.js
// Jalan di stockbit.com. Baca langsung baris transaksi yang SUDAH dirender
// di layar - TIDAK ada fetch/XHR tambahan dibuat sama sekali.
//
// Stockbit ternyata punya BEBERAPA struktur tabel berbeda untuk widget yang
// sama (dashboard pakai <table> polos, halaman chart pakai komponen Ant
// Design dengan tabel header & isi terpisah, dan kolom yang muncul pun bisa
// beda - kadang ada Buyer/Seller, kadang tidak). Supaya tahan terhadap
// semua variasi itu, scraper ini TIDAK bergantung pada struktur tabel atau
// urutan kolom. Sebagai gantinya:
//   1) Baris transaksi dikenali lewat ciri yang stabil di semua varian:
//      ada elemen <p action="1"> (Buy) atau <p action="2"> (Sell).
//   2) Tiap sel dalam baris itu diklasifikasikan berdasarkan POLA ISINYA
//      sendiri (jam, kode saham, harga+perubahan%, lot, nilai, market,
//      broker beli/jual) - bukan posisi kolom ke berapa.

(function () {
  const UNIT = { K: 1e3, M: 1e6, B: 1e9, T: 1e12 };
  const TIME_RE = /^\d{1,2}:\d{2}:\d{2}$/;
  const VALUE_RE = /^[\d.,]+\s*[KMBT]$/i;
  const PLAIN_NUM_RE = /^[\d,]+(\.\d+)?$/;
  const CODE_RE = /^[A-Z]{3,6}$/;
  const MARKET_RE = /^[A-Z]{2}$/;

  function num(s) {
    const n = parseFloat(String(s || "").replace(/,/g, "").trim());
    return isFinite(n) ? n : NaN;
  }

  function parseValue(text) {
    const m = /^([\d.,]+)\s*([KMBT])$/i.exec(String(text || "").trim());
    if (!m) return NaN;
    const base = num(m[1]);
    return isFinite(base) ? base * UNIT[m[2].toUpperCase()] : NaN;
  }

  function txt(el) {
    return el ? el.textContent.replace(/\s+/g, " ").trim() : "";
  }

  // Sel broker beli/jual selalu punya <span> anak dengan teks persis "[D]"
  // atau "[F]" (domestik/asing) - ciri unik yang tidak dipakai elemen lain.
  function brokerTag(td) {
    for (const span of td.querySelectorAll("span")) {
      const t = txt(span);
      if (t === "[D]" || t === "[F]") return true;
    }
    return false;
  }

  function scrapeRow(tr) {
    const out = { time: "", code: "", price: NaN, change: NaN, action: "", lot: NaN, value: NaN, market: "", buyer: "", seller: "" };
    for (const td of tr.querySelectorAll(":scope > td")) {
      const t = txt(td);
      if (!t) continue;

      if (!out.time && TIME_RE.test(t)) { out.time = t; continue; }

      const priceP = td.querySelector("p[change]");
      if (priceP) {
        const m = /^([\d.,]+)\s*\(([-+]?[\d.,]+)%\)/.exec(t);
        out.price = m ? num(m[1]) : num(t);
        out.change = m ? num(m[2]) : num(priceP.getAttribute("change"));
        continue;
      }

      if (brokerTag(td)) {
        if (!out.buyer) out.buyer = t; else if (!out.seller) out.seller = t;
        continue;
      }

      if (/^(buy|sell)$/i.test(t)) { out.action = t; continue; }

      if (VALUE_RE.test(t)) { out.value = parseValue(t); continue; }

      if (!out.code && CODE_RE.test(t)) { out.code = t; continue; }

      if (!out.market && MARKET_RE.test(t)) { out.market = t; continue; }

      if (isNaN(out.lot) && PLAIN_NUM_RE.test(t)) { out.lot = num(t); continue; }
    }
    if (!out.code || !out.action) return null; // bukan baris transaksi yang valid
    return out;
  }

  function scrapeAll(container) {
    const rows = [];
    for (const tr of container.querySelectorAll("tr")) {
      if (!tr.querySelector("p[action]")) continue; // baris non-transaksi (header ukur, dll)
      const r = scrapeRow(tr);
      if (r) rows.push(r);
    }
    return rows;
  }

  function pushRows(rows) {
    if (!rows.length) return;
    chrome.storage.local.set({ rtRows: { rows, capturedAt: Date.now() } });
  }

  const liveContainers = new Set();

  function attachObserver(container) {
    liveContainers.add(container);
    pushRows(scrapeAll(container)); // snapshot awal
    const mo = new MutationObserver(() => pushRows(scrapeAll(container)));
    mo.observe(container, { childList: true, subtree: true, characterData: true });
    console.log("[stockbit-dom-scraper] mulai memantau sebuah tabel transaksi (tanpa fetch tambahan)");
  }

  let lastScan = 0;
  function findAndAttach() {
    // buang kontainer yang sudah tidak ada di halaman (navigasi SPA, ganti simbol, dst)
    for (const c of liveContainers) if (!c.isConnected) liveContainers.delete(c);

    const now = Date.now();
    if (now - lastScan < 300) return; // sedikit throttle, halaman bisa sangat sering berubah
    lastScan = now;

    for (const p of document.querySelectorAll("p[action]")) {
      const tr = p.closest("tr");
      if (!tr) continue;
      const container = tr.closest("tbody") || tr.parentElement;
      if (container && !liveContainers.has(container)) attachObserver(container);
    }
  }

  findAndAttach();
  const bodyObserver = new MutationObserver(() => findAndAttach());
  bodyObserver.observe(document.documentElement, { childList: true, subtree: true });
})();
