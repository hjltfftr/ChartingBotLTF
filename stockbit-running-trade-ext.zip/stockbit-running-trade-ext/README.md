# Stockbit Running Trade Capture (tahap 2: jembatan langsung, tanpa worker)

Versi ini sudah bisa menggantikan proxy worker (`workerchart.hujatulatif-7.workers.dev`)
sepenuhnya. Cara kerjanya:

1. Kamu login & buka stockbit.com di satu tab seperti biasa.
2. Ekstensi diam-diam menangkap token Bearer dari request yang memang dikirim
   halaman Stockbit itu sendiri ke `exodus.stockbit.com` (tidak membajak akun
   lain, cuma membaca token dari request yang sudah berjalan di tab kamu).
3. Di tab lain, halaman HTML kamu (`index_gabungan_screener_update_stockbit.html`)
   minta data lewat ekstensi ini. Ekstensi fetch langsung dari **background
   script**-nya sendiri pakai token yang tadi ditangkap - ini otomatis bebas
   CORS karena sudah dideklarasikan di `host_permissions`, jadi TIDAK butuh
   proxy worker lagi.

## Cara install (Chrome/Edge/Brave)

1. Buka `chrome://extensions`
2. Nyalakan "Developer mode" (pojok kanan atas)
3. Klik "Load unpacked" → pilih folder `stockbit-running-trade-ext` ini
4. **Kalau halaman HTML kamu dibuka langsung dari file (`file:///...`)**: klik
   "Details" pada ekstensi ini → nyalakan toggle **"Allow access to file URLs"**.
   Tanpa ini, Chrome tidak mengizinkan content script jalan di halaman `file://`.
   (Kalau kamu membuka halaman HTML lewat server lokal di `http://localhost`
   atau `http://127.0.0.1`, langkah ini tidak perlu.)

## Cara pakai

1. Buka tab baru → login ke stockbit.com, biarkan tab ini tetap terbuka
2. Tunggu beberapa detik (biar ekstensi sempat menangkap request & tokennya)
3. Buka file HTML kamu di tab lain
4. Lihat indikator kecil di dekat kolom "Proxy sendiri":
   - ⚪ ekstensi tidak terdeteksi → cek langkah "Allow access to file URLs" di atas
   - 🟡 ekstensi terhubung tapi token belum ada → tunggu/refresh tab Stockbit
   - 🟢 ekstensi terhubung, token otomatis aktif → siap jalan, kolom token
     manual & proxy worker sudah tidak dipakai lagi

Setelah 🟢, semua fitur yang sebelumnya butuh token manual (chart Stockbit,
Running Trade Global, dsb) otomatis jalan lewat ekstensi. Kalau ekstensi
sedang tidak aktif/token belum tertangkap, halaman otomatis balik ke jalur
lama (token manual + proxy worker), jadi tidak ada yang rusak.

## Catatan penting

- Token tersimpan di `chrome.storage.local` milik ekstensi (lokal di browser
  kamu), tidak dikirim ke server pihak ketiga mana pun selain
  `exodus.stockbit.com` sendiri.
- Token Stockbit biasanya kedaluwarsa dalam waktu tertentu - kalau badge
  berubah jadi error 401, cukup refresh/buka ulang tab stockbit.com yang
  sedang login, token baru akan tertangkap otomatis.
- Tetap cek Terms of Service Stockbit soal automated access - pemakaian
  otomatis yang agresif (polling sangat sering, ke banyak endpoint sekaligus)
  tetap berisiko kena pembatasan akun meskipun lewat ekstensi sendiri.
- File debug lama (`popup.html`, request capture umum) masih ada, dipakai
  kalau suatu saat perlu cari tahu endpoint lain yang belum didukung.

## Tahap 3: mode pasif murni (baca DOM, nol fetch tambahan)

Selain jalur fetch (tahap 2), ekstensi ini sekarang juga punya `dom-scraper.js`
yang membaca langsung tabel widget "Running Trade" yang sudah tampil di
stockbit.com - tanpa membuat request jaringan apa pun. Caranya:

1. Buka tab stockbit.com, login, lalu pastikan widget **Running Trade**
   (yang nampilin tabel Time/Code/Price/Action/Lot/Buyer/Seller/Value/Market)
   kelihatan di layar - biasanya ada di dashboard/beranda. Biarkan tab ini
   tetap terbuka (boleh di-minimize/pindah tab, asal tidak ditutup).
2. Ekstensi memantau tabel itu pakai `MutationObserver` - setiap kali Stockbit
   menambah baris baru di tabelnya sendiri (lewat jalur live mereka sendiri,
   WebSocket atau apa pun), ekstensi langsung membaca & meneruskannya.
3. Halaman HTML kamu otomatis menerima baris-baris ini lewat
   `chrome.storage.onChanged` (bukan polling - benar-benar hanya jalan saat
   ADA data baru) dan langsung tampil di tab "Running Trade Global", dengan
   keterangan "(baca DOM tab Stockbit, tanpa fetch)" di status.

Mode ini dan mode fetch (tahap 2) jalan berdampingan - mana pun yang lebih
dulu dapat data, itu yang masuk duluan ke tabel (dedup otomatis, baris yang
sama tidak dobel). Kalau kamu mau 100% pasif tanpa fetch tambahan sama
sekali, tinggal uncheck "Auto" di panel Running Trade Global pada HTML-nya -
data tetap jalan dari jalur DOM-scrape ini saja.

**Batasannya:** jalur ini cuma hidup selama tab Stockbit itu memang terbuka
dan widgetnya ter-mount. Tutup tabnya / navigasi keluar dari halaman yang
ada widget itu, datanya berhenti sampai dibuka lagi.
