// content.js
// Jalan di "isolated world" ekstensi. Tugasnya cuma dua:
// 1) Menyuntikkan injected.js ke halaman asli (supaya bisa membajak fetch/XHR
//    milik halaman, bukan milik ekstensi).
// 2) Menangkap pesan dari injected.js lalu meneruskannya ke background script.

(function () {
  // 1. Suntik injected.js
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("injected.js");
  script.onload = function () {
    this.remove();
  };
  (document.head || document.documentElement).appendChild(script);

  // 2. Relay pesan dari halaman ke background
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== "__sb_capture__") return;

    chrome.runtime.sendMessage({
      type: "CAPTURED_RESPONSE",
      payload: data.payload,
      pageUrl: location.href,
      capturedAt: Date.now(),
    });
  });
})();
