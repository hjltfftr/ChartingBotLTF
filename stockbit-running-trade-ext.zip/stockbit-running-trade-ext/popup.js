const listEl = document.getElementById("list");
const onlyRelevantEl = document.getElementById("onlyRelevant");

function render(captures) {
  const filtered = onlyRelevantEl.checked
    ? captures.filter((c) => c.relevant)
    : captures;

  if (filtered.length === 0) {
    listEl.innerHTML = "<p>Belum ada data. Buka/refresh halaman Stockbit dulu.</p>";
    return;
  }

  listEl.innerHTML = filtered
    .slice()
    .reverse()
    .map((c) => {
      const time = new Date(c.capturedAt).toLocaleTimeString();
      const bodyPreview = JSON.stringify(c.body, null, 2).slice(0, 800);
      return `
        <div class="entry ${c.relevant ? "relevant" : ""}">
          <div class="url">${c.url || "(tanpa url)"}</div>
          <div class="meta">${c.kind} · ${c.status} · ${time}</div>
          <pre>${bodyPreview}</pre>
        </div>
      `;
    })
    .join("");
}

function renderTokenStatus() {
  chrome.storage.local.get("sbToken", ({ sbToken }) => {
    const el = document.getElementById("tokenStatus");
    if (!sbToken || !sbToken.token) {
      el.innerHTML =
        "⚪ <b>Belum ada token tertangkap.</b><br>Buka tab stockbit.com, login, lalu buka halaman detail saham apa pun (bukan cuma beranda) supaya ada request ke exodus.stockbit.com.";
      return;
    }
    const age = Math.round((Date.now() - sbToken.capturedAt) / 1000);
    el.innerHTML = `🟢 <b>Token tertangkap</b> (${sbToken.via || "fetch/xhr"})<br>${age} detik lalu, dari <span style="word-break:break-all">${sbToken.url || ""}</span>`;
  });
}

function renderRtStatus() {
  chrome.storage.local.get("rtRows", ({ rtRows }) => {
    const el = document.getElementById("rtStatus");
    if (!rtRows || !Array.isArray(rtRows.rows) || !rtRows.rows.length) {
      el.innerHTML =
        "⚪ <b>Belum ada hasil baca tabel Running Trade.</b><br>Pastikan widget Running Trade kelihatan di tab Stockbit.";
      return;
    }
    const age = Math.round((Date.now() - rtRows.capturedAt) / 1000);
    const codes = rtRows.rows.slice(0, 5).map((r) => r.code).join(", ");
    const color = age > 10 ? "🟡" : "🟢";
    el.innerHTML = `${color} <b>${rtRows.rows.length} baris terbaca</b>, ${age} detik lalu.<br>Contoh kode: ${codes}`;
  });
}

function load() {
  renderTokenStatus();
  renderRtStatus();
  chrome.runtime.sendMessage({ type: "GET_CAPTURES" }, (res) => {
    render(res?.captures || []);
  });
}

document.getElementById("refresh").addEventListener("click", load);
onlyRelevantEl.addEventListener("change", load);
document.getElementById("clear").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "CLEAR_CAPTURES" }, load);
});

load();
setInterval(load, 1000); // auto-refresh biar "X detik lalu" jalan terus tanpa perlu klik Refresh
