// injected.js
// Jalan di konteks halaman stockbit.com (bukan konteks ekstensi), supaya bisa
// membungkus window.fetch dan XMLHttpRequest milik halaman itu sendiri.
//
// Dua hal yang ditangkap:
// 1) Token Bearer yang dipakai halaman untuk memanggil exodus.stockbit.com
//    (ini token sesi login kamu sendiri - dipakai ulang oleh background
//    script ekstensi untuk fetch langsung, menggantikan proxy worker).
// 2) Response JSON (opsional, untuk riset endpoint lain lewat popup).

(function () {
  const TAG = "__sb_capture__";

  function send(payload) {
    window.postMessage({ source: TAG, payload }, "*");
  }

  function maybeCaptureToken(url, headerValue) {
    if (!headerValue) return;
    if (!/exodus\.stockbit\.com/i.test(String(url || ""))) return;
    const m = /^Bearer\s+(.+)$/i.exec(String(headerValue).trim());
    const token = m ? m[1] : String(headerValue).trim();
    if (!token) return;
    send({ type: "token", url, token });
  }

  function headerFromInit(init) {
    if (!init || !init.headers) return null;
    const h = init.headers;
    try {
      if (typeof h.get === "function") return h.get("authorization") || h.get("Authorization");
      if (Array.isArray(h)) {
        const f = h.find(([k]) => /^authorization$/i.test(k));
        return f ? f[1] : null;
      }
      for (const k of Object.keys(h)) {
        if (/^authorization$/i.test(k)) return h[k];
      }
    } catch (e) {}
    return null;
  }

  // --- Bungkus fetch ---
  const origFetch = window.fetch;
  window.fetch = async function (...args) {
    try {
      const url = typeof args[0] === "string" ? args[0] : args[0]?.url;
      maybeCaptureToken(url, headerFromInit(args[1]));
    } catch (e) {}

    const response = await origFetch.apply(this, args);
    try {
      const url = typeof args[0] === "string" ? args[0] : args[0]?.url;
      const clone = response.clone();
      const contentType = clone.headers.get("content-type") || "";
      if (contentType.includes("application/json")) {
        clone
          .json()
          .then((body) => {
            send({ type: "fetch", url, status: response.status, body });
          })
          .catch(() => {});
      }
    } catch (e) {
      // diam saja kalau ada error parsing, jangan ganggu halaman asli
    }
    return response;
  };

  // --- Bungkus XMLHttpRequest ---
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__sb_url = url;
    return origOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    if (/^authorization$/i.test(name)) {
      this.__sb_auth = value;
    }
    return origSetHeader.call(this, name, value);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    try {
      maybeCaptureToken(this.__sb_url, this.__sb_auth);
    } catch (e) {}

    this.addEventListener("load", function () {
      try {
        const contentType = this.getResponseHeader("content-type") || "";
        if (contentType.includes("application/json")) {
          const body = JSON.parse(this.responseText);
          send({ type: "xhr", url: this.__sb_url, status: this.status, body });
        }
      } catch (e) {
        // diam saja
      }
    });
    return origSend.apply(this, args);
  };

  console.log("[stockbit-capture] injected.js aktif (menangkap token + response)");
})();
