// background.js
// Dua peran:
// 1) Terima data tangkapan dari content.js (tab stockbit.com) - termasuk token
//    Bearer otomatis - simpan di chrome.storage.local.
// 2) Layani permintaan "SBX_REQUEST" dari bridge.js (tab HTML lokal kamu):
//    - action "ping"  -> info apakah token sudah ada
//    - action "fetch" -> fetch beneran ke exodus.stockbit.com pakai token
//      tersimpan. Fetch dari background/service worker dengan host_permissions
//      yang sudah dideklarasikan TIDAK kena CORS, jadi ini menggantikan proxy
//      worker eksternal sepenuhnya.

// --- Penangkapan token level JARINGAN (tahan CSP) ---
// Ini mengintip header request yang BENAR-BENAR dikirim browser ke
// exodus.stockbit.com, apa pun cara halaman membuatnya (fetch, XHR, fetch
// polyfill internal bundler, dsb). Tidak bergantung pada content script bisa
// jalan di halaman atau tidak, jadi tahan terhadap CSP ketat.
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    const auth = (details.requestHeaders || []).find((h) => /^authorization$/i.test(h.name));
    if (!auth || !auth.value) return;
    const m = /^Bearer\s+(.+)$/i.exec(auth.value.trim());
    const token = m ? m[1] : auth.value.trim();
    if (!token) return;
    chrome.storage.local.set({
      sbToken: { token, capturedAt: Date.now(), url: details.url, via: "webRequest" },
    });
  },
  { urls: ["https://exodus.stockbit.com/*"] },
  ["requestHeaders", "extraHeaders"]
);

const MAX_ENTRIES = 300;
const KEYWORDS = ["trade", "running", "order", "tick", "quote", "match"];

function looksRelevant(entry) {
  const haystack = (entry.url || "").toLowerCase();
  return KEYWORDS.some((k) => haystack.includes(k));
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // --- dari content.js (tab stockbit.com) ---
  if (message.type === "CAPTURED_RESPONSE") {
    const payload = message.payload || {};

    if (payload.type === "token") {
      chrome.storage.local.set({
        sbToken: { token: payload.token, capturedAt: message.capturedAt, url: payload.url },
      });
      return; // tidak perlu disimpan juga ke log captures
    }

    chrome.storage.local.get({ captures: [] }, ({ captures }) => {
      const entry = {
        url: payload.url,
        kind: payload.type, // "fetch" atau "xhr"
        status: payload.status,
        body: payload.body,
        capturedAt: message.capturedAt,
        pageUrl: message.pageUrl,
      };
      entry.relevant = looksRelevant(entry);

      captures.push(entry);
      if (captures.length > MAX_ENTRIES) {
        captures.splice(0, captures.length - MAX_ENTRIES);
      }
      chrome.storage.local.set({ captures });
    });
    return;
  }

  if (message.type === "CLEAR_CAPTURES") {
    chrome.storage.local.set({ captures: [] }, () => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === "GET_CAPTURES") {
    chrome.storage.local.get({ captures: [] }, ({ captures }) => {
      sendResponse({ captures });
    });
    return true;
  }

  // --- dari bridge.js (tab HTML lokal) ---
  if (message.type === "SBX_REQUEST") {
    (async () => {
      const { sbToken } = await chrome.storage.local.get("sbToken");

      if (message.action === "ping") {
        const hasToken = !!(sbToken && sbToken.token);
        const tokenAge = sbToken ? Date.now() - sbToken.capturedAt : null;
        sendResponse({ ok: true, hasToken, tokenAge });
        return;
      }

      if (message.action === "fetch") {
        if (!sbToken || !sbToken.token) {
          sendResponse({
            ok: false,
            error: "Token Stockbit belum tertangkap. Buka tab stockbit.com, login, dan biarkan sebentar.",
          });
          return;
        }
        try {
          const r = await fetch(message.url, {
            headers: { authorization: "Bearer " + sbToken.token },
          });
          const text = await r.text();
          let data;
          try {
            data = JSON.parse(text);
          } catch (e) {
            data = text;
          }
          if (!r.ok) {
            sendResponse({
              ok: false,
              error:
                "HTTP " + r.status + (r.status === 401 ? " (token kadaluarsa, buka ulang tab Stockbit)" : ""),
              status: r.status,
              data,
            });
            return;
          }
          sendResponse({ ok: true, data, status: r.status });
        } catch (e) {
          sendResponse({ ok: false, error: e.message });
        }
        return;
      }

      sendResponse({ ok: false, error: "action tidak dikenal: " + message.action });
    })();
    return true; // async sendResponse
  }
});
